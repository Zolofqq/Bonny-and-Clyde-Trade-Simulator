﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Изначальные балансы
        double balance1 = 10; // Изначальный баланс для актива 1
        double balance2 = 10; // Изначальный баланс для актива 2

        // Счетчик для отчета
        int totalTrades = 0; // Общее количество сделок

        Random rand = new Random(); // Инициализация генератора случайных чисел

        bool ProfitTrade = false; // Переменная для отслеживания прибыльных сделок

        // Цикл продолжается до выполнения условий:
        // 1. Сумма балансов меньше 1000.
        // 2. Общее количество сделок меньше 10000.
        // 3. Сумма балансов больше 1.
        while ((balance1 + balance2) < 1000 && totalTrades < 10000 && (balance1 + balance2) > 1)
        {
            double StartBalance1 = balance1; // Начальный баланс для актива 1
            double StartBalance2 = balance2; // Начальный баланс для актива 2
            double ProfitPerTrade = 0; // Прибыль за текущую сделку
            int randomNumber = rand.Next(1, 101); // Генерация случайного числа от 1 до 100

            // Генерация случайного числа в интервале [1, 100].
            // Если число больше или равно 50, это считается прибыльной сделкой.
            if (randomNumber >= 50 && randomNumber < 99)
            {
                balance1 = balance1 + (balance1 * 50 / 100) - (StartBalance1 * 20 * 0.02 / 100); // Прибыльная сделка: увеличение баланса актива 1
                balance2 = balance2 - (balance2 * 40 / 100) - (StartBalance2 * 20 * 0.05 / 100); // Убыточная сделка: уменьшение баланса актива 2

                ProfitTrade = true; // Установка значения прибыльной сделки
            }
            else if (randomNumber < 50)
            {
                balance2 = balance2 + (balance2 * 50 / 100) - (StartBalance2 * 20 * 0.02 / 100); // Прибыльная сделка: увеличение баланса актива 2
                balance1 = balance1 - (balance1 * 40 / 100) - (StartBalance1 * 20 * 0.05 / 100); // Убыточная сделка: уменьшение баланса актива 1

                ProfitTrade = false; // Установка значения прибыльной сделки
            }
            else if (randomNumber >= 99)
            {
                balance1 = balance1 - (balance1 * 40 / 100) - (StartBalance1 * 20 * 0.02 / 100); // Убыточная сделка: уменьшение баланса актива 1
                balance2 = balance2 - (balance2 * 40 / 100) - (StartBalance2 * 20 * 0.05 / 100); // Убыточная сделка: уменьшение баланса актива 2

                ProfitTrade = false; // Установка значения прибыльной сделки
            }

            // Если сделка прибыльная и баланс второго актива превышает баланс первого актива,
            // перераспределить прибыль так, чтобы балансы были равны.
            if (ProfitTrade == false)
            {
                if (balance2 > balance1)
                {
                    ProfitPerTrade = balance2 - StartBalance2; // Вычисление прибыли от убыточной сделки
                    balance1 = balance1 + (ProfitPerTrade / 2); // Распределение прибыли между активами
                    balance2 = balance2 - (ProfitPerTrade / 2); // Распределение прибыли между активами
                }
            }
            else // Если сделка прибыльная
            {
                if (balance1 > balance2)
                {
                    ProfitPerTrade = balance1 - StartBalance1; // Вычисление прибыли от прибыльной сделки
                    balance2 = balance2 + (ProfitPerTrade / 2); // Распределение прибыли между активами
                    balance1 = balance1 - (ProfitPerTrade / 2); // Распределение прибыли между активами
                }
            }

            totalTrades++; // Увеличение счетчика сделок
            // Вывод информации о текущей сделке
            Console.WriteLine($"Сделка {totalTrades}, профит за сделку {ProfitPerTrade}, значение баланса1: {balance1}, значение баланса2: {balance2}");
        }
        // Вывод информации о количестве сделок
        Console.WriteLine($"Всего сделок: {totalTrades}");
    }
}
